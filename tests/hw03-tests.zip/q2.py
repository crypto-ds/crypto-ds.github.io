OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 2.5,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw2_q2():\n'
                                               '...     public_key_q2 = PublicKey(curve=Curve(p=115792089237316195423570985008687907853269984665640564039457584007908834671663, a=0, b=7), '
                                               'x=114933019481968704587208047922620791312444083917521732599534582704263298890652, '
                                               'y=72616341544486364134146417615243068701027995450696140936695924235016748881211)\n'
                                               "...     m_3 = b'message 3'\n"
                                               '...     sig_3 = Signature(r=105339749489031988501239326383035148375668681012347172593671914296952541876309, '
                                               's=48841690192671967399092413880800041579365363922807727587156124998860780140605)\n'
                                               '...     secret_key_q2 = q2_recover_sk_weak(public_key_q2, m_3, sig_3)\n'
                                               "...     assert secret_key_q2 != None, 'failed to find the secret key'\n"
                                               "...     sig_4 = sign(secret_key_q2, b'message_4', 1)\n"
                                               "...     sig_5 = sign(secret_key_q2, b'hello_world', 2)\n"
                                               "...     assert verify(public_key_q2, b'message_4', sig_4) == True\n"
                                               "...     assert verify(public_key_q2, b'hello_world', sig_5) == True\n"
                                               '...     return\n'
                                               '>>> test_hw2_q2()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
