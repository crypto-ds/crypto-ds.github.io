OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 2.5,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw5q1_validity():\n'
                                               '...     for threshold in range(1, 7):\n'
                                               '...         num_parties = 3 * threshold + 1\n'
                                               '...         consistent_zeros = [Value.Zero] * num_parties\n'
                                               '...         consistent_ones = [Value.One] * num_parties\n'
                                               '...         for input in [consistent_zeros, consistent_ones]:\n'
                                               '...             for _ in range(500 * (7 - threshold)):\n'
                                               '...                 gradecastNetwork = SynchronousNetwork(GradecastParty, threshold, num_parties, input, debug=False)\n'
                                               '...                 result = gradecastNetwork.run(2)\n'
                                               '...                 for i in range(num_parties):\n'
                                               '...                     if gradecastNetwork.parties[i].is_malicious == False:\n'
                                               "...                         assert result[i] == (input[0], Grade.Satisfactory), 'failed validity test'\n"
                                               '...     return\n'
                                               '>>> test_hw5q1_validity()\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> def test_hw5q1_knowledge_of_agreement():\n'
                                               '...     for threshold in range(1, 7):\n'
                                               '...         num_parties = 3 * threshold + 1\n'
                                               '...         for _ in range(70 * 2 ** (7 - threshold)):\n'
                                               '...             consistent_zeros = [Value.Zero] * num_parties\n'
                                               '...             consistent_ones = [Value.One] * num_parties\n'
                                               '...             skewed_zeros = random.choices([Value.Zero, Value.One], weights=[4, 1], k=num_parties)\n'
                                               '...             skewed_ones = random.choices([Value.Zero, Value.One], weights=[1, 4], k=num_parties)\n'
                                               '...             for input in [consistent_zeros, consistent_ones, skewed_zeros, skewed_ones]:\n'
                                               '...                 gradecastNetwork = SynchronousNetwork(GradecastParty, threshold, num_parties, input, debug=False)\n'
                                               '...                 result = gradecastNetwork.run(2)\n'
                                               '...                 for val in [Value.Zero, Value.One]:\n'
                                               '...                     if (val, Grade.Satisfactory) in result:\n'
                                               '...                         for i in range(num_parties):\n'
                                               '...                             if gradecastNetwork.parties[i].is_malicious == False:\n'
                                               "...                                 assert result[i][0] == val and (result[i][1] == Grade.Close or result[i][1] == Grade.Satisfactory), 'failed "
                                               "knowledge of agreement test'\n"
                                               '...     return\n'
                                               '>>> test_hw5q1_knowledge_of_agreement()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
