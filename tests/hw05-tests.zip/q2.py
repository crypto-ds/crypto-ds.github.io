OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 2.5,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw5q2():\n'
                                               '...     for threshold in range(1, 7):\n'
                                               '...         num_parties = 3 * threshold + 1\n'
                                               '...         leader_zero = [Value.Zero] + [Value.Null] * (num_parties - 1)\n'
                                               '...         leader_one = [Value.One] + [Value.Null] * (num_parties - 1)\n'
                                               '...         for input in [leader_zero, leader_one]:\n'
                                               '...             for _ in range(25 * 2 ** (7 - threshold)):\n'
                                               '...                 phaseking = SynchronousNetwork(PhaseKingParty, threshold, num_parties, input, debug=False)\n'
                                               '...                 result = phaseking.run(3 * (threshold + 1))\n'
                                               '...                 for i in reversed(range(threshold + 1)):\n'
                                               '...                     if phaseking.parties[i].is_malicious == False:\n'
                                               '...                         expected_output = result[i]\n'
                                               '...                 for i in range(num_parties):\n'
                                               '...                     if phaseking.parties[i].is_malicious == False:\n'
                                               "...                         assert result[i] == expected_output, 'failed consistency test'\n"
                                               '...                 if phaseking.parties[0].is_malicious == False:\n'
                                               "...                     assert expected_output == input[0], 'failed validity test'\n"
                                               '...     return\n'
                                               '>>> test_hw5q2()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
