OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': '>>> modulus_q2 = 11\n'
                                               '>>> def test_hw8q2():\n'
                                               '...     for secret in range(modulus_q2):\n'
                                               '...         for slope in range(modulus_q2):\n'
                                               '...             for x1 in range(1, modulus_q2):\n'
                                               '...                 for x2 in range(1, modulus_q2):\n'
                                               '...                     if x1 == x2:\n'
                                               '...                         continue\n'
                                               '...                     shares = [(x1, (secret + slope * x1) % modulus_q2), (x2, (secret + slope * x2) % modulus_q2)]\n'
                                               '...                     result = q2_threshold_reconstruct(shares)\n'
                                               "...                     assert result == secret, 'did not reconstruct the correct secret'\n"
                                               '>>> test_hw8q2()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
