OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q3',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': '>>> modulus_q3 = 11\n'
                                               '>>> def test_hw8q3():\n'
                                               '...     for secret in range(modulus_q3):\n'
                                               '...         for a in range(modulus_q3):\n'
                                               '...             for b in range(modulus_q3):\n'
                                               '...                 for x1 in range(1, modulus_q3):\n'
                                               '...                     for x2 in range(1, modulus_q3):\n'
                                               '...                         for x3 in range(1, modulus_q3):\n'
                                               '...                             if x1 == x2 or x1 == x3 or x2 == x3:\n'
                                               '...                                 continue\n'
                                               '...                             shares = [(x, (a * x * x + b * x + secret) % modulus_q3) for x in (x1, x2, x3)]\n'
                                               '...                             result = q3_shamir_reconstruct(shares)\n'
                                               "...                             assert result == secret, 'did not reconstruct the correct secret'\n"
                                               '>>> test_hw8q3()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
