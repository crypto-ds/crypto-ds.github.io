OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> import random\n'
                                               '>>> def test_hw8q1():\n'
                                               '...     modulus_q1 = 10\n'
                                               '...     def split(secret):\n'
                                               '...         x0 = random.randrange(modulus_q1)\n'
                                               '...         x1 = random.randrange(modulus_q1)\n'
                                               '...         x2 = (secret - x0 - x1) % modulus_q1\n'
                                               '...         assert x2 >= 0 and x2 <= modulus_q1 - 1\n'
                                               '...         return [[x0, x1], [x1, x2], [x2, x0]]\n'
                                               '...     for a in range(10):\n'
                                               '...         for b in range(10):\n'
                                               '...             for _ in range(1000):\n'
                                               '...                 AliceShares = split(a)\n'
                                               '...                 BobShares = split(b)\n'
                                               '...                 zeroShares = zeroShare()\n'
                                               '...                 product = 0\n'
                                               '...                 for partyID in range(3):\n'
                                               '...                     share_of_product = q1_mpc_mult(partyID, AliceShares[partyID], BobShares[partyID], zeroShares[partyID])\n'
                                               "...                     assert share_of_product >= 0 and share_of_product <= modulus_q1 - 1, 'share must be between 0 and 9'\n"
                                               '...                     product += share_of_product\n'
                                               "...                 assert a * b % modulus_q1 == product % modulus_q1, 'did not compute the correct answer'\n"
                                               '...     AliceShares = [[0, 0], [0, 0], [0, 0]]\n'
                                               '...     BobShares = [[0, 0], [0, 0], [0, 0]]\n'
                                               '...     partyID = 0\n'
                                               '...     firstComputingServerShares = set()\n'
                                               '...     for _ in range(1000):\n'
                                               '...         zeroShares = zeroShare()\n'
                                               '...         share_of_product = q1_mpc_mult(partyID, AliceShares[partyID], BobShares[partyID], zeroShares[partyID])\n'
                                               '...         firstComputingServerShares.add(share_of_product)\n'
                                               "...     assert firstComputingServerShares == set(range(10)), 'did not use zeroShare to return a random share'\n"
                                               '...     return\n'
                                               '>>> test_hw8q1()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
