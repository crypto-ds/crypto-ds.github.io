OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw4_q4():\n'
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     dishonest_blockchain = q4_generate_dishonest_blockchain()\n'
                                               "...     assert len(dishonest_blockchain) >= 3, 'Dishonest blockchain should contain at least 3 blocks'\n"
                                               '...     is_A_to_E_two_coins = False\n'
                                               '...     for (index, block) in enumerate(dishonest_blockchain):\n'
                                               '...         for trans in block.transactions:\n'
                                               '...             payload = trans.transaction_payload\n'
                                               '...             assert not (index == 0 and payload.sender_public_key == public_keys[0] and (payload.receiver_public_key == public_keys[1]) and '
                                               "(payload.amount == 1)), 'Must remove the A->B transaction from the first block'\n"
                                               '...             if payload.sender_public_key == public_keys[0] and payload.receiver_public_key == public_keys[4] and (payload.amount == 2):\n'
                                               '...                 is_A_to_E_two_coins = True\n'
                                               "...     assert is_A_to_E_two_coins == True, 'Must create an A->E transaction that pays 2 coins'\n"
                                               "...     assert q2_findBalance(dishonest_blockchain, [1, 0, 1, 0, 0]) == [0, 0, 0, 0, 2], 'Dishonest blockchain should be valid and all coins should "
                                               "reside with player E'\n"
                                               '>>> test_hw4_q4()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
