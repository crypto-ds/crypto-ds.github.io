OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw4_q2():\n'
                                               "...     secret_key = ECC.generate(curve='P-256', randfunc=lambda x: b'0' * x)\n"
                                               '...     public_keys = '
                                               "[b'044d4385fe08e0eb94c524bdd3682c9c5ae358f52402df02418d0ba6cf6889289a27bd56a666df7dc595c98da1f22958009ae17c52fd290185d2e2bf11140a0a5e', "
                                               "b'04be4a2555cc8ed29989eeddde3d8e4d41458d02dce047aac2e6af2d58688c5beae7163eb157d1fd3c3d282abab7172b0f0d63274ebe721d31c5d72a83741df170', "
                                               "b'04a3fc575afc4ad2ca2cbeed50b52fedf049d317b790aa33e7f8182aec028453082d4c4ffd4c99c7e6d11c134e81020c57ca0fbf0bf3406bf4457dc72d8c994a65', "
                                               "b'04abc5bd2786ea5144122ccf43b89a557e1d36e2773c2b8986d9819a22c2e6540b3d5da692504ccc29fbf774435312afdda2a360d5160329cb326f6d47db29f50b', "
                                               "b'046a921bed68e07e66f38a5137b3784372cfd4507e6451e1dfe3760f08649750e7891cd30339b730c0280738c60233d3c99eb78454340ff363cafbf1e6f0cfce5e']\n"
                                               '...     def rerun_create_valid_blockchain():\n'
                                               '...         t1 = TransactionPayload(public_keys[0], public_keys[1], 1)\n'
                                               '...         t1_signature = '
                                               "b'edd6bb60e8486f9747f911a6d7340c275d5a417c3823952715a18a64d3577325413cf544e8f48e6c30a312649200c57b72d7eaa4721abf376dbd0dc799db6c3a'\n"
                                               '...         t1_signed = Transaction(t1, t1_signature)\n'
                                               '...         t2 = TransactionPayload(public_keys[2], public_keys[3], 1)\n'
                                               '...         t2_signature = '
                                               "b'33bcaaa920207125ec72ea7f9e5fbddb993479dbe7122c6dfcf0a96f2e646dd90ff73c90c784f473480e32fd2fb68735af86458bc0434e5958f025cc9e0ddd59'\n"
                                               '...         t2_signed = Transaction(t2, t2_signature)\n'
                                               "...         previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...         b0 = Block(0, [t1_signed, t2_signed], previous_hash, 7)\n'
                                               '...         t3 = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...         t3_signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...         t3_signed = Transaction(t3, t3_signature)\n'
                                               "...         previous_hash = b'00fd71161f8b5244d0641d83ccaedc2f0b7bed9d3f0c625fc817218660c4369a'\n"
                                               '...         b1 = Block(1, [t3_signed], previous_hash, 143)\n'
                                               '...         return [b0, b1]\n'
                                               '...     def rerun_create_all_blockchains():\n'
                                               '...         valid_blockchain = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_sig = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_sig[0].transactions[0].signature = '
                                               "b'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...         chain_invalid_difficulty = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_difficulty[1].nonce = 142\n'
                                               '...         chain_invalid_hash = rerun_create_valid_blockchain()\n'
                                               "...         chain_invalid_hash[1].previous_hash = b'2222222222222222222222222222222222222222222222222222222222222222'\n"
                                               '...         chain_invalid_balance = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_balance[0].transactions[0].transaction_payload = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...         chain_invalid_balance[0].transactions[0].signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...         return (valid_blockchain, chain_invalid_sig, chain_invalid_difficulty, chain_invalid_hash, chain_invalid_balance)\n'
                                               '...     (valid_blockchain, invalid1, invalid2, invalid3, invalid4) = rerun_create_all_blockchains()\n'
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               "...     assert q2_findBalance(valid_blockchain, players_balance) == [1, 1, 0, 0, 0], 'Should return final balance [1, 1, 0, 0, 0] for the "
                                               "valid_blockchain'\n"
                                               "...     assert q2_findBalance(invalid1, players_balance) == False, 'Should reject a blockchain that contains an invalid block'\n"
                                               "...     assert q2_findBalance(invalid2, players_balance) == False, 'Should reject a blockchain that contains an invalid block'\n"
                                               "...     assert q2_findBalance(invalid3, players_balance) == False, 'Should reject a blockchain that contains an invalid pointer to the previous hash'\n"
                                               "...     assert q2_findBalance(invalid4, players_balance) == False, 'Should reject a blockchain in which a player spends money they do not have'\n"
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     invalid_blockchain = rerun_create_valid_blockchain()\n'
                                               "...     invalid_blockchain[1].previous_hash = b'2222222222222222222122222122222222222222222222222222222222222222'\n"
                                               "...     assert q2_findBalance(invalid_blockchain, players_balance) == False, 'Should reject a blockchain that contains an invalid pointer to the "
                                               "previous hash'\n"
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     chain_insufficient_balance = rerun_create_valid_blockchain()\n'
                                               '...     t1 = TransactionPayload(public_keys[0], public_keys[1], 3)\n'
                                               '...     t1_signature = '
                                               "b'd2192800ce32cb719264ad8e770230e1e5e7ea626629fea29dc1234ef2179fefc145952e8ada18471eb423dd999220ba8b16d2187f15f33fe55fdc8deecae50c'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               "...     previous_hash = b'00ada715cd964e14b36d5d16369640d384f64024406171b0937d2521ccc1ccd9'\n"
                                               '...     b2 = Block(2, [t1_signed], previous_hash, 175)\n'
                                               '...     chain_insufficient_balance.append(b2)\n'
                                               "...     assert q2_findBalance(chain_insufficient_balance, players_balance) == False, 'Should reject a blockchain in which a player spends money they "
                                               "do not have'\n"
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     test_bad_signature = rerun_create_valid_blockchain()\n'
                                               "...     test_bad_signature[0].transactions[1].signature = b'2222222222222222222222222222222222222222222222222222222222222222'\n"
                                               "...     assert q2_findBalance(test_bad_signature, players_balance) == False, 'Should reject a blockchain that contains an invalid block'\n"
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     test_bad_balance = rerun_create_valid_blockchain()\n'
                                               '...     test_bad_balance[0].transactions[0].transaction_payload = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...     test_bad_balance[0].transactions[0].signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               "...     assert q2_findBalance(test_bad_balance, players_balance) == False, 'Should reject a blockchain in which a player spends coins they do not "
                                               "have'\n"
                                               '...     players_balance = [5, 0, 1, 0, 0]\n'
                                               '...     chain_valid_balance = rerun_create_valid_blockchain()\n'
                                               '...     t1 = TransactionPayload(public_keys[0], public_keys[1], 3)\n'
                                               '...     t1_signature = '
                                               "b'29121c1af1081f60f514c5cf9c1ffebc1f705c851401d1f212b7a1ab48695ec8ccd7fa12340cfda4bba305cfdbbe1d839d9079dbc3b2cae6bf0f58047db9b371'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               "...     previous_hash = b'00ada715cd964e14b36d5d16369640d384f64024406171b0937d2521ccc1ccd9'\n"
                                               '...     b2 = Block(2, [t1_signed], previous_hash, 717)\n'
                                               '...     chain_valid_balance.append(b2)\n'
                                               "...     assert q2_findBalance(chain_valid_balance, players_balance) == [2, 4, 0, 0, 0], 'Should accept a valid blockchain and reach the correct final "
                                               "balance'\n"
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     new_invalid_blockchain = []\n'
                                               '...     t1 = TransactionPayload(public_keys[2], public_keys[4], 3)\n'
                                               '...     t1_signature = '
                                               "b'9f44d74b4a5962492345ba9152cafbd02244fb646fca822b47633ce2c4efc1e36080b002312fd9bc3634a9cbc2eb5e1fee45993ec4d697e075c252832f62177a'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t2 = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...     t2_signature = '
                                               "b'821c18fad19e333903edf6c737068bcd1badb2fa24ac7410db56d0b65203cac60555507146e0422aa4b5371bde9c80f6d82ddde8c2a1b5cf210de4c10afd1ccb'\n"
                                               '...     t2_signed = Transaction(t2, t2_signature)\n'
                                               "...     previous_hash = b'00ada715cd964e14b36d5d16369640d384f64024406171b0937d2521ccc1ccd9'\n"
                                               '...     b1 = Block(2, [t1_signed, t2_signed], previous_hash, 4)\n'
                                               '...     t1 = TransactionPayload(public_keys[2], public_keys[4], 3)\n'
                                               '...     t1_signature = '
                                               "b'9f44d74b4a5962492345ba9152cafbd02244fb646fca822b47633ce2c4efc1e36080b002312fd9bc3634a9cbc2eb5e1fee45993ec4d697e075c252832f62177a'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t3 = TransactionPayload(public_keys[1], public_keys[0], 1)\n'
                                               '...     t3_signature_invalid = '
                                               "b'821c18fad19e3c3903edf6c737068bcd1badb2fa24ac7410db56d0b65203cac60555507146e0422aa4b5371bde9c80f6d82ddde8c2a1b5cf210de4c10afd1ccb'\n"
                                               '...     t3_signed_invalid = Transaction(t3, t3_signature_invalid)\n'
                                               "...     previous_hash = b'008cb3144b8292ed889be36f351f7843c6e475d5443d208a5d5c7849b24457db'\n"
                                               '...     b2 = Block(2, [t1_signed, t3_signed_invalid], previous_hash, 4)\n'
                                               '...     new_invalid_blockchain = [b1, b2]\n'
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               "...     assert q2_findBalance(new_invalid_blockchain, players_balance) == False, 'Should reject a blockchain that contains an invalid block'\n"
                                               '...     players_balance = [3, 3, 3, 3, 3]\n'
                                               '...     t1 = TransactionPayload(public_keys[4], public_keys[3], 1)\n'
                                               '...     t1_signature = '
                                               "b'8440dced32858d9b4ec8780822e41b4daf29b8221bd59cb1811dcf11a866be42b726f7d5cf5ec9d848f66ef9b0d8790073306c37e8cc38d3db013e67c0541fee'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t2 = TransactionPayload(public_keys[1], public_keys[0], 1)\n'
                                               '...     t2_signature = '
                                               "b'63bf7685ef20d44489e7028fbc8756b04f8f56e124d4c2231f9eac0f08657558cb6737436c130693d6eda861b4228dc433d6d266182a00e265d0fe936620bc14'\n"
                                               '...     t2_signed = Transaction(t2, t2_signature)\n'
                                               "...     previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...     b1 = Block(0, [t1_signed, t2_signed], previous_hash, 668)\n'
                                               '...     t3 = TransactionPayload(public_keys[0], public_keys[2], 2)\n'
                                               '...     t3_signature = '
                                               "b'c41bacc86d6ad9ba02a9d6bd6f1041545ccde2f9ef78a6a82a770e8d63b06f17523e4d51bdc1367e8a1c77d78ff5e91b3cdd8d529d6c9cb67edb230059c39897'\n"
                                               '...     t3_signed = Transaction(t3, t3_signature)\n'
                                               "...     previous_hash = b'006f607314121303c805ac82b77cc0ad3706574fba76d415511c4015b2692f05'\n"
                                               '...     b2 = Block(1, [t3_signed], previous_hash, 202)\n'
                                               '...     blockchain_valid = [b1, b2]\n'
                                               "...     assert q2_findBalance(blockchain_valid, players_balance) == [2, 2, 5, 4, 2], 'Should accept a valid blockchain and reach the correct final "
                                               "balance'\n"
                                               '...     players_balance = [3, 3, 3, 3, 3]\n'
                                               '...     t1 = TransactionPayload(public_keys[4], public_keys[3], 1)\n'
                                               '...     t1_signature = '
                                               "b'921f3406955479ef6897603cb968fddc19020827263a29a745e86df5387f605298ec5b638e9bcb105e3298353a1c94d7a84785bd33b6edd7c4153db1c47746b4'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t2 = TransactionPayload(public_keys[1], public_keys[0], 1)\n'
                                               '...     t2_signature = '
                                               "b'ae74565f772263b39ed369d3fcc0d9f260f36c468dd2815bdae4e95a7b23fc618626888cb2beccf31dbcf2d962ff89454a7c77797e4c80436a9dc5cb6da462a9'\n"
                                               '...     t2_signed = Transaction(t2, t2_signature)\n'
                                               "...     previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...     b1 = Block(0, [t1_signed, t2_signed], previous_hash, 55)\n'
                                               '...     t1 = TransactionPayload(public_keys[0], public_keys[2], 2)\n'
                                               '...     t1_signature = '
                                               "b'dfe75e8ae69bd9cbc20ad01c9cde9e03cd51a471fd18dfb091f8586ff9a381fc9a5b05b413b2b2b29dba07b42d24f099a85a4447aa7690ed6be27c2f279fc84b'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     b2 = Block(0, [t1_signed, t2_signed], previous_hash, 160)\n'
                                               '...     blockchain_invalidA = [b1, b2]\n'
                                               "...     assert q2_findBalance(blockchain_invalidA, players_balance) == False, 'Should reject a blockchain that contains an invalid pointer to the "
                                               "previous hash'\n"
                                               '...     players_balance = [3, 3, 3, 3, 3]\n'
                                               '...     t1 = TransactionPayload(public_keys[4], public_keys[3], 1)\n'
                                               '...     t1_signature = '
                                               "b'a3187f73e5b79720506252a42aa55e77b39a3e952d10fc71c4f46ddab31163cb6df3f7ce21dca1fe2ca7ae90afcf4d8fab80d5369db3e60c6ddc128c7426afe1'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t2 = TransactionPayload(public_keys[1], public_keys[0], 1)\n'
                                               '...     t2_signature = '
                                               "b'1a9676039f943c576f5992c89a8fe769c686fd50fb41566934495745ae19c20bf593d3a2ade974add43c20b51d270b4069bf3b3e4ef76ecb93b218845dd2e9d7'\n"
                                               '...     t2_signed = Transaction(t2, t2_signature)\n'
                                               "...     previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...     b1 = Block(0, [t1_signed, t2_signed], previous_hash, 1088)\n'
                                               '...     t1 = TransactionPayload(public_keys[0], public_keys[2], 2)\n'
                                               '...     t1_signature = '
                                               "b'8f78e8e14aa97faa14d1d63aa82175b2e2ba45c27a47731c99c4175adca42ba35a102a459eb89972ff9ca39511bf0e308f0dd7b7dfcde368750b58d28f281176'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               "...     previous_hash = b'100c66e1fcb4e8b0cd15b194931e3e0eda8b5a5634b2ac42f2217c0e964a9eaf'\n"
                                               '...     b2 = Block(1, [t1_signed], previous_hash, 634)\n'
                                               '...     blockchain_invalidB = [b1, b2]\n'
                                               "...     assert q2_findBalance(blockchain_invalidB, players_balance) == False, 'Should reject a blockchain that contains an invalid block'\n"
                                               '>>> test_hw4_q2()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
