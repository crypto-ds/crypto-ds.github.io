OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw4_q1():\n'
                                               "...     secret_key = ECC.generate(curve='P-256', randfunc=lambda x: b'0' * x)\n"
                                               '...     public_keys = '
                                               "[b'044d4385fe08e0eb94c524bdd3682c9c5ae358f52402df02418d0ba6cf6889289a27bd56a666df7dc595c98da1f22958009ae17c52fd290185d2e2bf11140a0a5e', "
                                               "b'04be4a2555cc8ed29989eeddde3d8e4d41458d02dce047aac2e6af2d58688c5beae7163eb157d1fd3c3d282abab7172b0f0d63274ebe721d31c5d72a83741df170', "
                                               "b'04a3fc575afc4ad2ca2cbeed50b52fedf049d317b790aa33e7f8182aec028453082d4c4ffd4c99c7e6d11c134e81020c57ca0fbf0bf3406bf4457dc72d8c994a65', "
                                               "b'04abc5bd2786ea5144122ccf43b89a557e1d36e2773c2b8986d9819a22c2e6540b3d5da692504ccc29fbf774435312afdda2a360d5160329cb326f6d47db29f50b', "
                                               "b'046a921bed68e07e66f38a5137b3784372cfd4507e6451e1dfe3760f08649750e7891cd30339b730c0280738c60233d3c99eb78454340ff363cafbf1e6f0cfce5e']\n"
                                               '...     def rerun_create_valid_blockchain():\n'
                                               '...         t1 = TransactionPayload(public_keys[0], public_keys[1], 1)\n'
                                               '...         t1_signature = '
                                               "b'edd6bb60e8486f9747f911a6d7340c275d5a417c3823952715a18a64d3577325413cf544e8f48e6c30a312649200c57b72d7eaa4721abf376dbd0dc799db6c3a'\n"
                                               '...         t1_signed = Transaction(t1, t1_signature)\n'
                                               '...         t2 = TransactionPayload(public_keys[2], public_keys[3], 1)\n'
                                               '...         t2_signature = '
                                               "b'33bcaaa920207125ec72ea7f9e5fbddb993479dbe7122c6dfcf0a96f2e646dd90ff73c90c784f473480e32fd2fb68735af86458bc0434e5958f025cc9e0ddd59'\n"
                                               '...         t2_signed = Transaction(t2, t2_signature)\n'
                                               "...         previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...         b0 = Block(0, [t1_signed, t2_signed], previous_hash, 7)\n'
                                               '...         t3 = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...         t3_signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...         t3_signed = Transaction(t3, t3_signature)\n'
                                               "...         previous_hash = b'00fd71161f8b5244d0641d83ccaedc2f0b7bed9d3f0c625fc817218660c4369a'\n"
                                               '...         b1 = Block(1, [t3_signed], previous_hash, 143)\n'
                                               '...         return [b0, b1]\n'
                                               '...     def rerun_create_all_blockchains():\n'
                                               '...         valid_blockchain = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_sig = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_sig[0].transactions[0].signature = '
                                               "b'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...         chain_invalid_difficulty = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_difficulty[1].nonce = 142\n'
                                               '...         chain_invalid_hash = rerun_create_valid_blockchain()\n'
                                               "...         chain_invalid_hash[1].previous_hash = b'2222222222222222222222222222222222222222222222222222222222222222'\n"
                                               '...         chain_invalid_balance = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_balance[0].transactions[0].transaction_payload = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...         chain_invalid_balance[0].transactions[0].signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...         return (valid_blockchain, chain_invalid_sig, chain_invalid_difficulty, chain_invalid_hash, chain_invalid_balance)\n'
                                               '...     (valid_blockchain, invalid1, invalid2, invalid3, invalid4) = rerun_create_all_blockchains()\n'
                                               "...     assert q1_verifyBlock(valid_blockchain[0]) == True, 'Should accept a valid block'\n"
                                               "...     assert q1_verifyBlock(invalid1[0]) == False, 'Should reject a block containing an invalid signature'\n"
                                               "...     assert q1_verifyBlock(invalid1[1]) == True, 'Should accept a valid block'\n"
                                               "...     assert q1_verifyBlock(invalid2[0]) == True, 'Should accept a valid block'\n"
                                               "...     assert q1_verifyBlock(invalid2[1]) == False, 'Should reject a block with an invalid nonce'\n"
                                               '...     tx_in_valid_block = Transaction(TransactionPayload(public_keys[0], public_keys[1], 1), '
                                               "b'edd6bb60e8486f9747f911a6d7340c275d5a417c3823952715a18a64d3577325413cf544e8f48e6c30a312649200c57b72d7eaa4721abf376dbd0dc799db6c3a')\n"
                                               "...     hash_in_valid_block = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...     nonce_in_valid_block = 316\n'
                                               '...     valid_block = Block(0, [tx_in_valid_block], hash_in_valid_block, nonce_in_valid_block)\n'
                                               "...     assert q1_verifyBlock(valid_block) == True, 'Should accept a valid block'\n"
                                               '...     tx_in_invalid_block_two = Transaction(TransactionPayload(public_keys[0], public_keys[1], 1), '
                                               "b'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000')\n"
                                               "...     hash_in_invalid_block_two = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...     nonce_in_invalid_block_two = 226\n'
                                               '...     invalid_block_two = Block(0, [tx_in_invalid_block_two], hash_in_invalid_block_two, nonce_in_invalid_block_two)\n'
                                               "...     assert q1_verifyBlock(invalid_block_two) == False, 'Should reject a block containing an invalid signature'\n"
                                               '...     tp_in_invalid_block_one = TransactionPayload(public_keys[2], public_keys[4], 3)\n'
                                               '...     sig_in_invalid_block_one = '
                                               "b'69d1d28a8b757d038e4bb767cbf69179b2d41081f43c31736667976e106d94ac379e5c4aac2541d5b78eb064d58c42df759148889e31514b23479ed1b7ff9a10'\n"
                                               '...     tx_in_invalid_block_one = Transaction(tp_in_invalid_block_one, sig_in_invalid_block_one)\n'
                                               "...     hash_in_invalid_block_one = b'00ada715cd964e14b36d5d18369640d384f64024406171b0937d2521ccc1c1d9'\n"
                                               '...     nonce_in_invalid_block_one = 327\n'
                                               '...     invalid_block_one = Block(2, [tx_in_invalid_block_one], hash_in_invalid_block_one, nonce_in_invalid_block_one)\n'
                                               "...     assert q1_verifyBlock(invalid_block_one) == False, 'Should reject a block with an invalid nonce'\n"
                                               '...     tx = Transaction(TransactionPayload(public_keys[0], public_keys[1], 1), '
                                               "b'edd6bb60e8486f9747f911a6d7340c275d5a417c3823952715a18a64d3577325413cf544e8f48e6c30a312649200c57b72d7eaa4721abf376dbd0dc799db6c3a')\n"
                                               "...     previous_hash = b'2222222222222222222222222222222222222222222222222222222222222222'\n"
                                               "...     assert q1_verifyBlock(Block(1, [tx], previous_hash, 350)) == True, 'Should accept a valid block'\n"
                                               '...     tx.signature = '
                                               "'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'\n"
                                               "...     assert q1_verifyBlock(Block(1, [tx], previous_hash, 19)) == False, 'Should reject a block containing an invalid signature'\n"
                                               '...     tx = Transaction(TransactionPayload(public_keys[2], public_keys[3], 1), '
                                               "'33bcaaa920207125ec72ea7f9e5fbddb993479dbe7122c6dfcf0a96f2e646dd90ff73c90c784f473480e32fd2fb68735af86458bc0434e5958f025cc9e0ddd59')\n"
                                               "...     previous_hash = b'0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'\n"
                                               "...     assert q1_verifyBlock(Block(1, [tx], previous_hash, 98)) == True, 'Should accept a valid block'\n"
                                               '...     tx.signature = '
                                               "b'0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'\n"
                                               "...     assert q1_verifyBlock(Block(1, [tx], previous_hash, 332)) == False, 'Should reject a block containing an invalid signature'\n"
                                               '...     t1 = TransactionPayload(public_keys[0], public_keys[1], 1)\n'
                                               '...     t1_signature = '
                                               "b'edd6bb60e8486f9747f911a6d7340c275d5a417c3823952715a18a64d3577325413cf544e8f48e6c30a312649200c57b72d7eaa4721abf376dbd0dc799db6c3a'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t2 = TransactionPayload(public_keys[2], public_keys[3], 1)\n'
                                               '...     t2_signature = '
                                               "b'33bcaaa920207125ec72ea7f9e5fbddb993479dbe7122c6dfcf0a96f2e646dd90ff73c90c784f473480e32fd2fb68735af86458bc0434e5958f025cc9e0ddd59'\n"
                                               '...     t2_signed = Transaction(t2, t2_signature)\n'
                                               "...     previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...     list_of_ranges = [range(4), range(5, 6), range(8, 15), range(17, 25)]\n'
                                               '...     for aList in list_of_ranges:\n'
                                               '...         for nonce in aList:\n'
                                               '...             bad_block = Block(0, [t1_signed, t2_signed], previous_hash, nonce)\n'
                                               "...             assert q1_verifyBlock(bad_block) == False, 'Should reject a block with an invalid nonce'\n"
                                               '...     t3 = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...     t3_signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...     t3_signed = Transaction(t3, t3_signature)\n'
                                               "...     previous_hash = b'00fd71161f8b5244d0641d83ccaedc2f0b7bed9d3f0c625fc817218660c4369a'\n"
                                               '...     b1 = Block(1, [t3_signed], previous_hash, 453)\n'
                                               "...     assert q1_verifyBlock(b1) == False, 'Should reject a block with an invalid nonce'\n"
                                               '...     t1 = TransactionPayload(public_keys[2], public_keys[4], 3)\n'
                                               '...     t1_signature = '
                                               "b'c8fa5c6a32e605d1cd14731e6a98e82001099275d94863d5d115f1b686e36e4816df5219084fd6879985c9754f97529cadf6d4da14ed6db1a232d0de3c2bf64a'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               "...     previous_hash = b'00ada715cd964e14b36d5d16369640d384f64024406171b0937d2521ccc1ccd9'\n"
                                               '...     block_valid = Block(2, [t1_signed], previous_hash, 425)\n'
                                               "...     assert q1_verifyBlock(block_valid) == True, 'Should accept a valid block'\n"
                                               '...     t1 = TransactionPayload(public_keys[2], public_keys[4], 3)\n'
                                               '...     t1_signature = '
                                               "b'c8fa5c6a32e605d1cd14731e6a98e82001099275d94863d5d115f1b686e36e4816df5219084fd6879985c9754f97529cadf6d4da14ed6db1a232d0de3c2bf64a'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               "...     previous_hash = b'00ada715cd964e14b36d5d16369640d384f64024406171b0937d2521ccc1ccd9'\n"
                                               '...     b1 = Block(2, [t1_signed], previous_hash, 400)\n'
                                               "...     assert q1_verifyBlock(b1) == False, 'Should reject a block with an invalid nonce'\n"
                                               '...     t1 = TransactionPayload(public_keys[2], public_keys[4], 3)\n'
                                               '...     t1_signature = '
                                               "b'9f44d74b4a5962492345ba9152cafbd02244fb646fca822b47633ce2c4efc1e36080b002312fd9bc3634a9cbc2eb5e1fee45993ec4d697e075c252832f62177a'\n"
                                               '...     t1_signed = Transaction(t1, t1_signature)\n'
                                               '...     t2 = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...     t2_signature = '
                                               "b'821c18fad19e333903edf6c737068bcd1badb2fa24ac7410db56d0b65203cac60555507146e0422aa4b5371bde9c80f6d82ddde8c2a1b5cf210de4c10afd1ccb'\n"
                                               '...     t2_signed = Transaction(t2, t2_signature)\n'
                                               "...     previous_hash = b'00ada715cd964e14b36d5d16369640d384f64024406171b0937d2521ccc1ccd9'\n"
                                               '...     b1 = Block(2, [t1_signed, t2_signed], previous_hash, 4)\n'
                                               "...     assert q1_verifyBlock(b1) == True, 'Should accept a valid block'\n"
                                               '>>> test_hw4_q1()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
