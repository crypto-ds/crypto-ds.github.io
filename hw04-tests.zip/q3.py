OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_hw4_q3():\n'
                                               "...     secret_key = ECC.generate(curve='P-256', randfunc=lambda x: b'0' * x)\n"
                                               '...     public_keys = '
                                               "[b'044d4385fe08e0eb94c524bdd3682c9c5ae358f52402df02418d0ba6cf6889289a27bd56a666df7dc595c98da1f22958009ae17c52fd290185d2e2bf11140a0a5e', "
                                               "b'04be4a2555cc8ed29989eeddde3d8e4d41458d02dce047aac2e6af2d58688c5beae7163eb157d1fd3c3d282abab7172b0f0d63274ebe721d31c5d72a83741df170', "
                                               "b'04a3fc575afc4ad2ca2cbeed50b52fedf049d317b790aa33e7f8182aec028453082d4c4ffd4c99c7e6d11c134e81020c57ca0fbf0bf3406bf4457dc72d8c994a65', "
                                               "b'04abc5bd2786ea5144122ccf43b89a557e1d36e2773c2b8986d9819a22c2e6540b3d5da692504ccc29fbf774435312afdda2a360d5160329cb326f6d47db29f50b', "
                                               "b'046a921bed68e07e66f38a5137b3784372cfd4507e6451e1dfe3760f08649750e7891cd30339b730c0280738c60233d3c99eb78454340ff363cafbf1e6f0cfce5e']\n"
                                               '...     def rerun_create_valid_blockchain():\n'
                                               '...         t1 = TransactionPayload(public_keys[0], public_keys[1], 1)\n'
                                               '...         t1_signature = '
                                               "b'edd6bb60e8486f9747f911a6d7340c275d5a417c3823952715a18a64d3577325413cf544e8f48e6c30a312649200c57b72d7eaa4721abf376dbd0dc799db6c3a'\n"
                                               '...         t1_signed = Transaction(t1, t1_signature)\n'
                                               '...         t2 = TransactionPayload(public_keys[2], public_keys[3], 1)\n'
                                               '...         t2_signature = '
                                               "b'33bcaaa920207125ec72ea7f9e5fbddb993479dbe7122c6dfcf0a96f2e646dd90ff73c90c784f473480e32fd2fb68735af86458bc0434e5958f025cc9e0ddd59'\n"
                                               '...         t2_signed = Transaction(t2, t2_signature)\n'
                                               "...         previous_hash = b'0000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...         b0 = Block(0, [t1_signed, t2_signed], previous_hash, 7)\n'
                                               '...         t3 = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...         t3_signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...         t3_signed = Transaction(t3, t3_signature)\n'
                                               "...         previous_hash = b'00fd71161f8b5244d0641d83ccaedc2f0b7bed9d3f0c625fc817218660c4369a'\n"
                                               '...         b1 = Block(1, [t3_signed], previous_hash, 143)\n'
                                               '...         return [b0, b1]\n'
                                               '...     def rerun_create_all_blockchains():\n'
                                               '...         valid_blockchain = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_sig = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_sig[0].transactions[0].signature = '
                                               "b'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'\n"
                                               '...         chain_invalid_difficulty = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_difficulty[1].nonce = 142\n'
                                               '...         chain_invalid_hash = rerun_create_valid_blockchain()\n'
                                               "...         chain_invalid_hash[1].previous_hash = b'2222222222222222222222222222222222222222222222222222222222222222'\n"
                                               '...         chain_invalid_balance = rerun_create_valid_blockchain()\n'
                                               '...         chain_invalid_balance[0].transactions[0].transaction_payload = TransactionPayload(public_keys[3], public_keys[0], 1)\n'
                                               '...         chain_invalid_balance[0].transactions[0].signature = '
                                               "b'886de552f43010b2a848f660b066102e680a4c6b763032c98c53e6f86c5d5638a9dee5e41f311e4956cd416a51850afa28bc4b9575cbf9cbf1940fae84b1d166'\n"
                                               '...         return (valid_blockchain, chain_invalid_sig, chain_invalid_difficulty, chain_invalid_hash, chain_invalid_balance)\n'
                                               '...     (oldBC, invalid1, invalid2, invalid3, invalid4) = rerun_create_all_blockchains()\n'
                                               '...     newBC = q3_mineHonestBlockThree()\n'
                                               '...     assert oldBC[0].json_encode() == newBC[0].json_encode()\n'
                                               '...     assert oldBC[1].json_encode() == newBC[1].json_encode()\n'
                                               '...     players_balance = [1, 0, 1, 0, 0]\n'
                                               '...     for block in newBC:\n'
                                               "...         assert q1_verifyBlock(block), 'Each block in the blockchain should be valid'\n"
                                               '...     players_balance = q2_findBalance(newBC, players_balance)\n'
                                               "...     assert players_balance == [0, 1, 0, 0, 1], 'Incorrect final balance'\n"
                                               '...     new_block = newBC[-1]\n'
                                               '...     transactions = new_block.transactions\n'
                                               '...     if len(transactions) == 1:\n'
                                               '...         transaction = transactions[0]\n'
                                               '...         payload = transaction.transaction_payload\n'
                                               '...         if payload.sender_public_key == public_keys[0] and payload.receiver_public_key == public_keys[4] and (payload.amount == 1):\n'
                                               '...             return True\n'
                                               '...     return False\n'
                                               ">>> assert test_hw4_q3() == True, 'Cannot find a transaction in which A pays 1 coin to E'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
