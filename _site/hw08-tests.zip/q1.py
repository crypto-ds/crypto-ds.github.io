OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify, unhexlify\n'
                                               '>>> from Cryptodome.Hash import HMAC, SHA256\n'
                                               '>>> def test_hw8q1():\n'
                                               '...     sha2 = lambda x: hexlify(SHA256.new(x).digest())\n'
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'5f103f40aea987399d5dd75b2bc4060877af5ef4e4f528e2abe20b948286ba25'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'if with well so of', leaky_hmac_verify_testing)) == "
                                               "b'32a0a037dda9d1f8841f9562d949aa5ecd98a76fed8b60c8db8539cc592163c4'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'4e1a7ea3fc6bb83b19e15d5f1e563dcdb43347b6940e294ed25a81757ee4cb4c'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'make know no if these', leaky_hmac_verify_testing)) == "
                                               "b'9f9f2623a7e7e2090b48c2d55131a10a28aa0cc012392b077911316c849d1d0e'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'9b9e1c96f5532362a8985c079955c2043fe7fc82cb071f27f0e206a196eebc52'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'you up would my after', leaky_hmac_verify_testing)) == "
                                               "b'6508f35a9135f8be1a8d36c0481cc08e4bf7af1919a1f8b4cfe9b23ab6a1e2eb'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'e132bdb9fa27b0a190ab48229a27612872568d1f4aaec1fb14bdb34b07bf49c8'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'look these first give go', leaky_hmac_verify_testing)) == "
                                               "b'bcfe2bd1ba1bbe73c1f4d7c69af210be76c70079e7e3ae8f4ff9a6ab4e389b07'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'56f1cf4d1ea7e5141f6b530e8e8c8d2215e6c3412e0202805bac09188e73d82d'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'other if but she all', leaky_hmac_verify_testing)) == "
                                               "b'7392a28ea30160c6f09cce476287f94d9ebd18697b3a3204d5e4ba38013a7e99'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'136048e0228e631c5bd92f2f082f61c260d30d5232310cb026359e8121480abe'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'could or some about year', leaky_hmac_verify_testing)) == "
                                               "b'14537e77517cec1b8d00729f2692f59f18c088d6394b49e49d9ff9749aa5c748'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'27ef856e1a13386ed8c17bad7ce4104bd31108cb3e9bdaa5a900ce8725210435'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'give if if what have', leaky_hmac_verify_testing)) == "
                                               "b'13079c00d5c61ddf1c0eea341f97cb0d4877a71def7af8886a2a07719d9dc7f9'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'c279b01db7b58ede6712ba64e6bf28b9869a818dada6128e518ac6e7e9119e95'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'new look so new on', leaky_hmac_verify_testing)) == "
                                               "b'bac377629184fb2084da47605375f5345e95fa5f26c695f86ba1f137759c9caf'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'd556cb9e3360aa48ff252ca7911153872fbae197163fd1ce8a8e90a9c8fa4dfe'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'want take you look most', leaky_hmac_verify_testing)) == "
                                               "b'3eef2a2d95240add439a7084d8c6df203e3860da527ed82dfe4a14fdc9be5d52'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'03fa2b8edf927719f0aa6d23d5c04f46a6b74c778bdf2afff912162d79812c4a'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'with even her back say', leaky_hmac_verify_testing)) == "
                                               "b'1bec4b656dd0adf1e0f378e6dad46fbbfee4c2d4b19c7802211424f50301b9ea'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'ca715d5e43a9669810173ff84ecc6383c7386bf7be1cd6bb36d2f9de207c43f1'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'new these know other good', leaky_hmac_verify_testing)) == "
                                               "b'6d7e377e2d9cf06b098ba8e54f3dba1f1bbbfa26579f6c6f828d22cdb11294eb'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'2a385961a0c728b3351cf7e68a260e9d584f2f6a93a363e019f7be17d0564329'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'back her any after that', leaky_hmac_verify_testing)) == "
                                               "b'2f6efbed82a6c82fc1d019cf450a36f25ab1bae701e269abfc519b6cf6e227d3'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'3cc70b32e83b435db8a93a71f3de2de386a48b99460d3ced1bde8568aa19e682'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'be them him because how', leaky_hmac_verify_testing)) == "
                                               "b'15ef16a4fb436e713e47d04ec2a1ba2de3038ddc23ba039f7ac64ca206bdb147'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'496baebfe1f2f356efc6de5a0e82983fcb3e449ba0c84afe62ea2fbfc8866956'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'when know which into your', leaky_hmac_verify_testing)) == "
                                               "b'66b490babc2dbe5dfe22825ee10dbc36796f14251761f19c8fdfca898b3df00a'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'e02c142f07e5d9362b55436556e84aaa9f6096dfdeda240645cf62ae8c5fa5a3'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'these about on they person', leaky_hmac_verify_testing)) == "
                                               "b'75a10b399666e1d0d04c626d6f488bb3e3f37386c00b72c3ddfff1d5f69f328b'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'62e6335d0e5595564cc32d427089fe7baddea9031d2c2ce8fecefe1abef20f77'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'there who about it have', leaky_hmac_verify_testing)) == "
                                               "b'd75051ba5dfbec400a2ff0c7ef1c90f883ffa70362b16a4f0ce309f2a91087d8'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'3b374ebe97d262bd4ad0888fc4a06c7a200547191724e0ca0949907c80f959fd'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'because year from could or', leaky_hmac_verify_testing)) == "
                                               "b'bb41a52e717cd78cc55647081173487e23c5d48ff2c4f07542f42f70dd2e0d8d'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'd2628c83993816b20af8f00c98cb667c7301d8a8c7a5a96f774ac4c1e8ae73fb'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'only say have when that', leaky_hmac_verify_testing)) == "
                                               "b'9d5fe2758c01b849836d0950cf2e6e7bd127ed854b6a108e9ee07dde5a98b85b'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'8428a0f4edbcb416c12ed707609288cf5a73416d7bd9efa5dfe872cd6684e34a'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'even two your when as', leaky_hmac_verify_testing)) == "
                                               "b'edf4c6c990017fa0e4ef70bccb082c819cadf1caaae14c2d899c0bbe2bbc08e2'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'51b4cd1b272b8560206775fd37a56961897e538cd7666bc037d2b6334382445f'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'or first year her your', leaky_hmac_verify_testing)) == "
                                               "b'798c528b900e874b3f8bae502841477805c1e89c14c931e6f752021243ff65e8'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'87e138320f744f2a97c82321b6c6b7b3fe470e5209b867d1d8b9d2a94a761443'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'but by her you into', leaky_hmac_verify_testing)) == "
                                               "b'e2a6ea3149411614e80a548bf0d581a73ec32108cad17d1b6594b6f26eccca98'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'6fdf96f9e1fc69afdfc1903e5229bd0d2ebaa88f5b644af331a0191da635506c'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'we up we into your', leaky_hmac_verify_testing)) == "
                                               "b'dc531b4ebba45e21e7775e6281db40a1418bc439d578be0e4c16756233b55943'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'bed887d4e3cc0e98858cfad3b0d392c5b7294150004c4e598f58ac3ccdfae817'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'want good get only his', leaky_hmac_verify_testing)) == "
                                               "b'0f02500551e4b9808ac7a3f01a7284cda743c18ec94be5fe3c3dde8856c0e611'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'd7ea167e2d073d0cd293b13cd3f4049262689d52e0180870fbe78d103148baa1'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'most could you want to', leaky_hmac_verify_testing)) == "
                                               "b'b7129cec3722185355fd65300960af5630862e4b9817a5dbd004aebf8484c86d'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'b99ae5176343298956548b9175b2535868df41286384c4f88d1a69feb2856d7d'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'into work well our just', leaky_hmac_verify_testing)) == "
                                               "b'e150c4030899b9a76dd61f574f7de65fdc15a20655aa45c2de9f7ccd3fc452f5'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'ac1dfc98f38c571b7a942c21e147c88e936a33e74acbdcebea3737035dc7da21'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'see your as because well', leaky_hmac_verify_testing)) == "
                                               "b'87642b800e316867c6468bff2fb66e8919a1d76f4a3404d1fb80bba8b958bf37'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'c7895c6aa78883b93d6f779087b7457b061e6eaf814132d557271c8220bed4bc'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'even my even if do', leaky_hmac_verify_testing)) == "
                                               "b'd9f1d9da04479b14485b38157a633bcd50fa9ecccc999987c6b5a1799c8b3db4'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'5c92201cc8c2a9f83154efbc175a6a9cd806f079b326a2171f3990470339cee0'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'now other just time in', leaky_hmac_verify_testing)) == "
                                               "b'710f521c63068bd562aa4330f955ab2779785047ae8d8549ff4ed4292112a4cf'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'b4105e02da63bdfbc76f21f40ce44af50ccd07f2e8c0a9f922d4f27a4b70ad71'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'have my come just it', leaky_hmac_verify_testing)) == "
                                               "b'11d16d9ec656a606e847389f73e439637396be31c30032435d9c44a0089ee937'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'8e955a351e99a021fd37a57c9b1cadf93e86671cad8ed4a1e8ae8a9900368f9d'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'then can get we these', leaky_hmac_verify_testing)) == "
                                               "b'1d4f454ab458a0f5fbae3993f1253e5b6d22585655cbd2b3d518bcb69df445b3'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'b67baaeebc42390a50919bf6c66d433b89ae19f7e75e8015cc6c59262d5ce531'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'us can one well which', leaky_hmac_verify_testing)) == "
                                               "b'0c41cdb452d4479017376a85f99286fb90c4eb2c63a4ef8af0c50601a62292ab'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'a7afed073c603bc96a152ed260ce78be577bc75db51ba052cbf0f20c63ed74d6'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'just or also way now', leaky_hmac_verify_testing)) == "
                                               "b'9fbcb4b19eeb5df36f9f341f814612967ad0da283d0b329c3f69e134688e2617'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'5a80746f1a493f098a0b0166b3e60d70bcdaaaf6616c9ae313bdf798d581bb72'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'he in now about one', leaky_hmac_verify_testing)) == "
                                               "b'ba7d239f5d427f010d47996c7f5892e8e50175ecfb8cf401cea0179b9fc7768d'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'068867223a47aa49c3762ecd12374fab36dfb49ca4f68c3293710cb68634d452'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'them by know which she', leaky_hmac_verify_testing)) == "
                                               "b'debdc343e73caddd49cae975b43f42f1cffef664fc73317692d25cd20d8ca7eb'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'bb7e83f4a4a5b3555f1b971cf08934504f56163380d007fbcf642788bdc6cb67'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'from most would the about', leaky_hmac_verify_testing)) == "
                                               "b'927aae5e149943067d1abcd3e8e0567eb93cdae9c84f434e4cdf323139495690'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'a7388b6c7be3b2758deffa25f2d03fb7280d55f1bde062aba6a15a96a62c396f'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'no could up his your', leaky_hmac_verify_testing)) == "
                                               "b'c23ad4e983d1a35c97f5485a5bd051f75d8a30bb02cb7d4ef02b727a1fb981d4'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'c59237276cdedcbb68d34ea95de6e0f40f50f8c084c3b2f2d5710e3e4b4de689'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'want us your just most', leaky_hmac_verify_testing)) == "
                                               "b'7ed614845f28f83b9503a4bd1e94ae9960d41af36bb7f9ef0755152b1cf09252'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'0bbcce0f938b904d720a71f86e655aa3dae7906efadfea7d863a746a2caaf484'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'use up its us say', leaky_hmac_verify_testing)) == "
                                               "b'5e496c09e804078ed7f52919b0e38c09016d563b9715ad1c870bfb0d467bc50f'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'a4eb46d9bcb2dc3fe3458a0a34b4d2460d7fdce4b4e71ab57a37a278d60c3559'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'now most want could take', leaky_hmac_verify_testing)) == "
                                               "b'eb5c1385eee23e448c01c2d4b60dc6db4236243a48a6564f5ff1f4ebcbd3d9c7'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'752dcbf8ce83265297918225225a778db90c3dd955d4f8691c617229ce971c9c'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'up up after about could', leaky_hmac_verify_testing)) == "
                                               "b'48256e0304342ab2f639a0d40914153983dc4a979d9805509a7c8b5e74c2e0ef'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'58ffb6915e965376c00fb1c5020f64a267e51862a96dedfcf90b37574609e262'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'new by give get for', leaky_hmac_verify_testing)) == "
                                               "b'aa8bfc2aa37bd0a42cbbc060fad726716f77047f55c96950f987a9e76d767fe5'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'd7f98afccafdd71cb72b13f782370a9aae404eccb98d88b6914eadf1a3b3b363'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'no well them of can', leaky_hmac_verify_testing)) == "
                                               "b'95e8aba465fc28fe0642de1b57a8564eb292facb41f7c61f08e67753f688fafd'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'5755ce6e7c3b58ad46e7f2fa2efcf5d088ff843ac614a5271857808763096488'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'what some them some look', leaky_hmac_verify_testing)) == "
                                               "b'bec26445cd83beeea3e3f4515d6499c77ed481f78954e24c58a009c15c66a638'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'48657e2e25dc5844b44fe111133c5b89435305d48fc181120c8159bcce6b550b'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'from see work for see', leaky_hmac_verify_testing)) == "
                                               "b'f966066ea98f2eecccd88d717451de65d1e6c5fe6d1df09779e3511f92d19b7a'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'413fb283f70e45f6f14cf6be1cfc2e960fc0e5456ed5e0aa9272a3e608312526'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'one that way after time', leaky_hmac_verify_testing)) == "
                                               "b'd22048204abb50210ec9d01b92d65156074828ed0fb151afa293cc330f21fa92'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'ebf05e395381b5ad05d345f47df289936756756058e227c8bceb9fea1987bb0b'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'year no way and and', leaky_hmac_verify_testing)) == "
                                               "b'df52dbc5a1d6033bc21ecdff48e92448613e2cf81aeb62931a8b418a30f57f86'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'0c5306e266334098560a6b9788ecaa91f7e79bc4da749fbcf428127f00aa1917'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'for want now over which', leaky_hmac_verify_testing)) == "
                                               "b'809530dd1146937fbbc6980bde6f60b8de7c35d4c70e7e126cb426a2234496ce'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'c2eb0a9cf7d7db4c092e4a633d6bece2176de337e6143b216b40da6e7ce746cf'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'give his what new then', leaky_hmac_verify_testing)) == "
                                               "b'c5f4d49c009ef972b1e28ce60bbe996b30c0fc7c3ed82b2079f850359327433e'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'8877384a431ecc9f8c309b6d665104a36629f29f41796ea7ffe82673f3b7c077'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'us into you will on', leaky_hmac_verify_testing)) == "
                                               "b'0e4ba76ee9da9c802af87242f1e1cf6c77bf5fa2c44ccf070f37cabaf940b60d'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'446587d71691d6f295b704a151aa08ff2b5d83e542aed2d8a51bde592c87dd91'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'which on my me know', leaky_hmac_verify_testing)) == "
                                               "b'35f075d049ed40a4da7f8c95bbc23dc94648829322019f9a5885a6b4c006d9fa'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'ba3738bc815daedf6a5d619d1ad455d8b063b3a2ef12017bbda28e6d8869198e'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'us than any can them', leaky_hmac_verify_testing)) == "
                                               "b'8b0279073cc742b43f01b1238ac6c3f0986cca06e348597b8cefeec545c27261'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'bad8b950a76aaefcdb3280c1aa645cba4bd3b05c7554705e530cd1c72e060d96'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'them would there see year', leaky_hmac_verify_testing)) == "
                                               "b'f9d6989d600c8fb843b4a8e90d37c9ce39f7ac43161ee87a799fb7bd10d2e9ed'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'6a68409b5d0fc692860c8eb5d529161c02e5d4aa6eaba310d13d36fc6a23919d'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'only say our its well', leaky_hmac_verify_testing)) == "
                                               "b'143c721344311f5a45cbda323991a27845f17bdf06bf93246b02c16f087da9fb'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'bfa91922b743daf2c68ad2616dd5ec1c0cabc8298f09395aeb51e3cad3605a54'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'also its also and look', leaky_hmac_verify_testing)) == "
                                               "b'59f3979ed0b194cd3fdd7e8eb5648e7fbb7ef3254974150374eb1fdf1e1d654e'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'407a1fae162e599f645eafeffcaa26635faf5248b99f21476f1682bbec62085d'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'her know with they him', leaky_hmac_verify_testing)) == "
                                               "b'79ec79b66212646ec7ab5ecc179d95dc6a64035e380e43207028113e4dbcad96'\n"
                                               "...     hmac_sha256_testing = lambda message: hexlify(HMAC.new(unhexlify(b'df8e84010ef95f8489a91712106cd8ee206b127a8e2206816b687e3acb01bf17'), "
                                               'message, SHA256).digest())\n'
                                               '...     leaky_hmac_verify_testing = lambda message, claimed_tag: leaky_hmac_verify(message, claimed_tag, hmac_sha256_testing)\n'
                                               "...     assert sha2(q1_forge_mac(b'also they but out other', leaky_hmac_verify_testing)) == "
                                               "b'de18471390eaae170b6567fd4da1a755216aa5a38144215a8845e3858ace9600'\n"
                                               '>>> test_hw8q1()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
