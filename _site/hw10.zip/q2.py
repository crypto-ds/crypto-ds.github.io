OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw10_q2().to_bytes(1, 'big') + b'a4f12e12733c7de326ea1d56657d5e34').digest()) == "
                                               "b'1967c72d3adf4d7abb31d77579f5db9a3c91ac358bbd0c6a79af107f3646b9ae', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
