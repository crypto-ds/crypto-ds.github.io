OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw10_q1().to_bytes(1, 'big') + b'2e42e7a661c58e1f6e52e8b322e94a0d').digest()) == "
                                               "b'42130f2643be005a5cefe3fc5dd6a20021da9e8dbf1de801f5444099e09ccd21', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
