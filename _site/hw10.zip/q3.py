OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw10_q3().to_bytes(1, 'big') + b'52d97b8efdf71f0c499c7dc48194a3e6').digest()) == "
                                               "b'ad639b07f4e7a604be1187e6a333f5b3b4c333b003e6cf7070e789d93339dddc', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
