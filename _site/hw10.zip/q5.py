OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q5',
    'points': 8,
    'suites': [   {   'cases': [   {   'code': '>>> from random import shuffle\n'
                                               '>>> from copy import deepcopy\n'
                                               '>>> from hashlib import sha256\n'
                                               '>>> from os import urandom\n'
                                               '>>> from binascii import hexlify, unhexlify\n'
                                               '>>> actual_puzzle = [[0, 2, 0, 6, 0, 8, 0, 0, 0], [5, 8, 0, 0, 0, 9, 7, 0, 0], [0, 0, 0, 0, 4, 0, 0, 0, 0], [3, 7, 0, 0, 0, 0, 5, 0, 0], [6, 0, 0, 0, '
                                               '0, 0, 0, 0, 4], [0, 0, 8, 0, 0, 0, 0, 1, 3], [0, 0, 0, 0, 2, 0, 0, 0, 0], [0, 0, 9, 8, 0, 0, 0, 3, 6], [0, 0, 0, 3, 0, 0, 0, 9, 0]]\n'
                                               '>>> actual_solution = [[1, 2, 3, 6, 7, 8, 9, 4, 5], [5, 8, 4, 2, 3, 9, 7, 6, 1], [9, 6, 7, 1, 4, 5, 3, 2, 8], [3, 7, 2, 4, 6, 1, 5, 8, 9], [6, 9, 1, '
                                               '5, 8, 3, 2, 7, 4], [4, 5, 8, 7, 9, 2, 6, 1, 3], [8, 3, 6, 9, 2, 4, 1, 5, 7], [2, 1, 9, 8, 5, 7, 4, 3, 6], [7, 4, 5, 3, 1, 6, 8, 9, 2]]\n'
                                               '>>> def randomize_puzzle(puzzle, solution):\n'
                                               '...     permutation = [1, 2, 3, 4, 5, 6, 7, 8, 9]\n'
                                               '...     shuffle(permutation)\n'
                                               '...     permutation.insert(0, 0)\n'
                                               '...     permuted_puzzle = deepcopy(puzzle)\n'
                                               '...     permuted_solution = deepcopy(solution)\n'
                                               '...     for i in range(9):\n'
                                               '...         for j in range(9):\n'
                                               '...             permuted_puzzle[i][j] = permutation[permuted_puzzle[i][j]]\n'
                                               '...             permuted_solution[i][j] = permutation[permuted_solution[i][j]]\n'
                                               '...     return (permutation, permuted_puzzle, permuted_solution)\n'
                                               '>>> class Com:\n'
                                               '...     def commit(message, one_time_secret):\n'
                                               '...         """\n'
                                               '...         precondition:\n'
                                               '...         before executing this command, create a one-time committer secret using code like:\n'
                                               '...         one_time_secret = hexlify(urandom(32))\n'
                                               '...         """\n'
                                               "...         message_bytes = bytes(str(message), 'ascii')\n"
                                               '...         return hexlify(sha256(message_bytes + one_time_secret).digest())\n'
                                               '...     def verify(commitment, message, one_time_secret):\n'
                                               "...         message_bytes = bytes(str(message), 'ascii')\n"
                                               '...         return commitment == hexlify(sha256(message_bytes + one_time_secret).digest())\n'
                                               '>>> def VerifierVictor(puzzle, solution):\n'
                                               '...     for _ in range(500):\n'
                                               '...         peggy = ProverPeggy(puzzle, solution)\n'
                                               '...         commitments = peggy.step_two()\n'
                                               '...         for row_index in range(9):\n'
                                               "...             row_vector = peggy.step_four('row', row_index)\n"
                                               '...             messages = [row_vector[i][0] for i in range(9)]\n'
                                               '...             secrets = [row_vector[i][1] for i in range(9)]\n'
                                               "...             assert set(messages) == set([1, 2, 3, 4, 5, 6, 7, 8, 9]), 'row does not contain messages 1-9 exactly once each'\n"
                                               '...             for j in range(9):\n'
                                               "...                 assert Com.verify(commitments[row_index][j], messages[j], secrets[j]) == True, 'row commitments are not all valid'\n"
                                               '...         for col_index in range(9):\n'
                                               "...             col_vector = peggy.step_four('col', col_index)\n"
                                               '...             messages = [col_vector[i][0] for i in range(9)]\n'
                                               '...             secrets = [col_vector[i][1] for i in range(9)]\n'
                                               "...             assert set(messages) == set([1, 2, 3, 4, 5, 6, 7, 8, 9]), 'column does not contain messages 1-9 exactly once each'\n"
                                               '...             for i in range(9):\n'
                                               "...                 assert Com.verify(commitments[i][col_index], messages[i], secrets[i]) == True, 'column commitments are not all valid'\n"
                                               '...         for sub_index in range(9):\n'
                                               "...             sub_vector = peggy.step_four('sub', sub_index)\n"
                                               '...             messages = [sub_vector[i][0] for i in range(9)]\n'
                                               '...             secrets = [sub_vector[i][1] for i in range(9)]\n'
                                               "...             assert set(messages) == set([1, 2, 3, 4, 5, 6, 7, 8, 9]), 'sub-grid does not contain messages 1-9 exactly once each'\n"
                                               '...             start_row = 3 * (sub_index // 3)\n'
                                               '...             start_col = 3 * sub_index % 9\n'
                                               '...             vec_index = 0\n'
                                               '...             for i in range(start_row, start_row + 3):\n'
                                               '...                 for j in range(start_col, start_col + 3):\n'
                                               "...                     assert Com.verify(commitments[i][j], messages[vec_index], secrets[vec_index]) == True, 'sub-grid commitments are not all "
                                               "valid'\n"
                                               '...                     vec_index = vec_index + 1\n'
                                               "...         (perm, vec) = peggy.step_four('perm', 0)\n"
                                               '...         messages = [vec[i][0] for i in range(len(vec))]\n'
                                               '...         secrets = [vec[i][1] for i in range(len(vec))]\n'
                                               '...         index = 0\n'
                                               '...         for i in range(9):\n'
                                               '...             for j in range(9):\n'
                                               '...                 if puzzle[i][j] != 0:\n'
                                               "...                     assert perm[puzzle[i][j]] == messages[index], 'permuted_puzzle is not consistent with permutation'\n"
                                               "...                     assert Com.verify(commitments[i][j], messages[index], secrets[index]), 'permuted_puzzle commitments are not all valid'\n"
                                               '...                     index = index + 1\n'
                                               '...     return True\n'
                                               '>>> assert VerifierVictor(actual_puzzle, actual_solution) == True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
