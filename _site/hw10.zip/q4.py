OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q4',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw10_q4().to_bytes(1, 'big') + b'c3624ec4948c09e30009a884612df480').digest()) == "
                                               "b'4dd90be1038f50e3c593a96a9dcc1ce1d409d9f890f90ac2f178e70c0b9df600', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
