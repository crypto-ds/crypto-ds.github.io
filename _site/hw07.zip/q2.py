OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw7_q2().to_bytes(1, 'big') + b'6221acd487e3fcc1019769c923af29ee').digest()) == "
                                               "b'61b72687daa35b9828a757d988cd8923ba87426fe02c1ca062a53f6d9841c56d', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
