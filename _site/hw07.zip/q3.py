OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw7_q3().to_bytes(1, 'big') + b'f94f2c547d060f9ed0f30845827c8433').digest()) == "
                                               "b'e5ae61ec7a8542cc1885950ddbce3445d272299c3daa4b113aaf7cd24dbfc799', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
