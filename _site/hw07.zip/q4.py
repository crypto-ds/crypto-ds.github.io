OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw7_q4().to_bytes(1, 'big') + b'b829d0cd076dbcfebbb173907d4e77db').digest()) == "
                                               "b'5473892187f5e37f58f8a9f0aea3059ca48ddf327436485ffd628c027a55be51', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
