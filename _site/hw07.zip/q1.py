OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> from binascii import hexlify\n'
                                               '>>> from hashlib import sha256\n'
                                               ">>> assert hexlify(sha256(hw7_q1().to_bytes(1, 'big') + b'98d6180646b84fe484330815115faec2').digest()) == "
                                               "b'51bf6920b1725e7e3a1a8bef7bf4ce67a04af1db35ecc8f135309d32bb8ebdcd', 'incorrect response, try again'\n",
                                       'failure_message': 'Try again',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Satisfactory'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
