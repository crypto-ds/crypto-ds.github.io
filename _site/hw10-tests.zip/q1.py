OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> import random\n'
                                               '>>> def test_hw10q1():\n'
                                               '...     modulus = 10\n'
                                               '...     def split(secret):\n'
                                               '...         x0 = random.randrange(modulus)\n'
                                               '...         x1 = random.randrange(modulus)\n'
                                               '...         x2 = (secret - x0 - x1) % modulus\n'
                                               '...         assert x2 >= 0 and x2 <= modulus - 1\n'
                                               '...         return [[x0, x1], [x1, x2], [x2, x0]]\n'
                                               '...     for a in range(10):\n'
                                               '...         for b in range(10):\n'
                                               '...             for _ in range(1000):\n'
                                               '...                 AliceShares = split(a)\n'
                                               '...                 BobShares = split(b)\n'
                                               '...                 product = 0\n'
                                               '...                 for partyID in range(3):\n'
                                               '...                     share_of_product = q1_mpc_mult(partyID, AliceShares[partyID], BobShares[partyID])\n'
                                               "...                     assert share_of_product >= 0 and share_of_product <= modulus - 1, 'share must be between 0 and 9'\n"
                                               '...                     product += share_of_product\n'
                                               "...                 assert a * b % modulus == product % modulus, 'did not compute the correct answer'\n"
                                               '...     return\n'
                                               '>>> test_hw10q1()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
