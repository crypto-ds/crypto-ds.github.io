OK_FORMAT = True

test = {   'all_or_nothing': True,
    'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> from hashlib import sha256\n'
                                               '>>> def test_hw6q2():\n'
                                               '...     claimed_list = q2_rsa_attack()\n'
                                               '...     assert type(claimed_list) == list\n'
                                               "...     assert len(claimed_list[0]) == 2, 'did not create a 2-dimensional list of [p, q] lists'\n"
                                               "...     assert len(claimed_list) == 12, 'did not factor the correct number of rsa_N moduli'\n"
                                               '...     for i in range(len(claimed_list)):\n'
                                               '...         claimed_list[i].sort()\n'
                                               '...     claimed_list.sort()\n'
                                               '...     def twodim_list_to_bytes(the_list):\n'
                                               "...         the_bytes = b'['\n"
                                               '...         for i in range(len(the_list)):\n'
                                               "...             the_bytes = the_bytes + b'[' + bytes(str(the_list[i][0]), 'ascii') + b', ' + bytes(str(the_list[i][1]), 'ascii') + b']'\n"
                                               '...             if i != len(the_list) - 1:\n'
                                               "...                 the_bytes = the_bytes + b', '\n"
                                               "...         the_bytes = the_bytes + b']'\n"
                                               '...         return the_bytes\n'
                                               '...     claimed_bytes = twodim_list_to_bytes(claimed_list)\n'
                                               "...     assert sha256(claimed_bytes).hexdigest() == '284b13569ec14d974ce794539e0c3a987446a73fe3bac21918801297d7d39b3d', 'incorrect list of [p, q] "
                                               "factors'\n"
                                               '>>> test_hw6q2()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
